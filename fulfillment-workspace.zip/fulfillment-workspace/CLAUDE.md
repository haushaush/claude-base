# FulfillmentOS

Regeln für **alle** Türen. Was hier steht, wird nirgends wiederholt — nicht in
`personas.json`, nicht in den Bereichsordnern. Eine Regel steht an genau einer
Stelle.

---

## Reihenfolge

Bei jeder Anfrage in dieser Reihenfolge:

1. Diese Datei
2. `.hermes/MEMORY.md` — global: Kunden, Fachdomäne, Arbeitsweise
3. `.hermes/bereiche/<tür>/MEMORY.md` — der Bereich, über den die Anfrage kam
4. `kunden-briefings/<slug>/master-briefing.md` — falls ein Kunde betroffen ist
5. Erst dann die Aufgabe

Bei Widersprüchen gewinnt das Master-Briefing des Kunden. Zwischen global und
bereichslokal gewinnt global.

---

## Ketten — verbindlich

**A · Copy**
`copywriter` → `qa-review` → Mensch.
QA ist NIE optional. Kein Text erreicht einen Menschen ungeprüft.

**B · Neuer Kunde**
`web-research` → `stratege` → Ablage unter `kunden-briefings/<slug>/`.
Ohne Master-Briefing kein Copy- und kein LP-Auftrag.

**C · Landingpage**
`stratege` → `lp-builder` PLAN → **Freigabe durch Menschen** → `copywriter` →
`qa-review` → `lp-builder` BAU → `qa-review`.
Das Skelett wird immer freigegeben, bevor gebaut wird.

**D · Performance**
`media-buyer` diagnostiziert READ-ONLY → Empfehlung an den Menschen.
Nie selbst eingreifen.

**E · Wettbewerb**
`web-research` → `stratege` → `copywriter`.
Analysieren, nie kopieren.

Die Tür bestimmt den **Einstieg**, nicht den Ablauf. `@copy` startet bei
`copywriter` — und läuft trotzdem durch `qa-review`.

---

## Gates

| Gate | Wann | Wer |
|---|---|---|
| Review | vor jedem Text an einen Menschen | `qa-review` |
| Skelett-Freigabe | vor jedem LP-Bau | Mensch |
| Master-Briefing | vor jedem Copy-/LP-Auftrag | liegt vor oder wird erstellt |
| Menschen-Haken | vor allem Irreversiblen: Livegang, Budget, Kundenkommunikation | Mensch |

Fehlt eine Voraussetzung, wird sie angefordert — nicht angenommen, nicht
umgangen. „Der Kunde hat es eilig" ist kein Grund, ein Gate zu überspringen;
es ist der Grund, warum es existiert.

---

## Leitplanken

1. **Erledigt = verifiziert.** Nachweis, nicht „gemacht". Ohne Beleg gilt es
   als offen.
2. **Keine erfundenen Zahlen.** Fehlt ein Beleg: `[PROOF: …]` und anfordern.
3. **Keine Zugangsdaten** in Briefings, Notizen oder Antworten. Nur Status.
4. **Media Buyer ist READ-ONLY.** Analysiert und empfiehlt, greift nicht ein.
5. **Keine erfundenen Testimonials**, keine erfundenen Auszeichnungen.
6. **Alles über Aufträge, nie über Zuruf.** Jede Übergabe trägt ihren Kontext.
7. **Single Source of Truth** ist das Master-Briefing.
8. **Rollen und Namen faktentreu.** Im Zweifel nachsehen statt schätzen.

---

## Wissensebenen

- `.hermes/` global: Kunden, Fachdomäne, Arbeitsweise. Jede Tür liest es.
- `.hermes/bereiche/<tür>/` bereichslokal: das Handwerk dieses Bereichs.
- Fremde Bereichsordner nicht lesen, ausser eine Kette verlangt es.
- **Schreibregel:** Würde eine andere Tür die Notiz brauchen? Ja → global,
  nein → lokal. Im Zweifel lokal.
- Jede neue Notiz bekommt eine Zeile im zuständigen `MEMORY.md`.

---

## Was NICHT hierher gehört

- Handwerk eines Bereichs → `.hermes/bereiche/<tür>/`
- Prozeduren mit Schrittfolge → ein Skill unter `.claude/skills/`
- Fakten über einen Kunden → `kunden-briefings/<slug>/`
- Aktueller Arbeitsstand → `CONTEXT.md`

Jede Zeile hier wird bei jeder Nachricht in jedem Thread mitgeschickt. Das ist
nur für Regeln gerechtfertigt, deren Verletzung teuer wäre.
