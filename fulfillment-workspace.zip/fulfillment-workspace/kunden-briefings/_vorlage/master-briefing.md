# Master-Briefing — <Kunde>

Single Source of Truth. Bei Widersprüchen zu Notizen oder Erinnerungen gewinnt
diese Datei.

Stand: <Datum> · Erstellt von: <stratege / Mensch>

---

## Kunde
- Firma:
- Ansprechpartner:
- Rolle:  <faktentreu — nicht raten>
- Branche / Nische:

## Angebot
- Was wird verkauft:
- Preisrahmen:
- Was ist der eigentliche Nutzen für den Kunden:
- Womit wird verglichen (Alternative des Interessenten):

## Zielgruppe
- Wer:
- Problem, das sie lösen wollen:
- Was sie bisher versucht haben:
- Einwände:

## Botschaft
- Kernbotschaft in einem Satz:
- Beweise (jeweils mit Quelle):
- Was NICHT gesagt werden darf:

## Rechtliches
- <PLATZHALTER: eure Pflichtangaben, z. B. Vermittlerstatus>
- Verbotene Formulierungen:

## Offen
- [PROOF: <was fehlt und wer es liefert>]
