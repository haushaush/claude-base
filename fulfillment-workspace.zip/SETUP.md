# FulfillmentOS aufsetzen

Gerüst, kein fertiges Set. Die Struktur, die Ketten und die Gates stehen —
die fachlichen Platzhalter musst du füllen, sonst arbeitet der Agent generisch.

## 1. Workspace einspielen

```bash
cd /opt/claude-bot
mkdir -p agents/fulfillment
cp -a fulfillment-workspace agents/fulfillment/workspace
```

## 2. Wissensstruktur anlegen

```bash
bash scaffold-context.sh agents/fulfillment/workspace \
     strat copy ads gfx
```

Die Bereichs-Keys müssen den `key`-Feldern in `personas.json` entsprechen —
sonst sucht eine Persona einen Ordner, den es nicht gibt.

## 3. Slack-Apps

```bash
bash make-manifests.sh strat:Strategie copy:Copywriting ads:Mediabuying gfx:Grafik
```

Je Manifest auf api.slack.com/apps: From an app manifest → Install →
`xoxb-` holen → Basic Information → App-Level Token mit `connections:write`
→ `xapp-` holen (wird nur einmal angezeigt).

Dann je einen Channel anlegen und die App einladen.

## 4. personas.json

```bash
cp personas.example.json agents/fulfillment/personas.json
nano agents/fulfillment/personas.json
chmod 600 agents/fulfillment/personas.json
chown -R 1000:1000 agents/fulfillment
```

Zuordnung:

| key | @Name | subagent | Prefix |
|---|---|---|---|
| strat | Strategie | stratege | strat |
| copy | Copywriting | copywriter | copy |
| ads | Mediabuying | media-buyer | ads |
| gfx | Grafik | — (noch kein Subagent) | gfx |

`@Grafik` hat noch keinen eigenen Subagent. Entweder `subagent` leer lassen —
dann arbeitet der Orchestrator selbst — oder erst einen `designer` schreiben.
Ich würde ihn vorerst weglassen und dazunehmen, wenn klar ist, was er tun soll.

## 5. Meta-Connector

```bash
cp connectors.env.example agents/fulfillment/connectors.env
nano agents/fulfillment/connectors.env
chmod 600 agents/fulfillment/connectors.env
```

## 6. Starten

```bash
docker compose --profile fulfillment up -d --build agent-fulfillment
docker compose logs -f agent-fulfillment
```

Erwartet: eine `personas:`-Zeile mit allen vier Türen.

## 7. Eigener Login

Der Container hat ein eigenes Home-Volume:

```bash
docker compose run --rm -it --entrypoint claude agent-fulfillment
#   Login, danach falls Onepage gebraucht wird:
#   claude mcp add --transport http --scope user onepage https://mcp.onepage.io/
#   /mcp -> authenticate
```

---

## Was noch fehlt — die Platzhalter

Ohne diese arbeitet das Set generisch. In dieser Reihenfolge würde ich sie
füllen:

1. **`copywriter.md` — Stil-DNA.** Der wichtigste. Ohne ihn ist der Copywriter
   ein beliebiger Textgenerator. Tonalität, Satzbau, verbotene Wörter, je ein
   Beispiel für gut und schlecht.
2. **`qa-review.md` — Compliance-Punkte.** Was rechtlich geprüft werden muss.
   Ohne das prüft das Gate nur Stil.
3. **`media-buyer.md` — Kennzahlen und Schwellen.** Was ist bei euch ein guter
   CPL, ab wann ist etwas auffällig.
4. **`stratege.md` — eure Briefing-Methodik.**
5. **`lp-builder.md` — Onepage-Konventionen.**
6. **`kunden-briefings/_vorlage/` — Pflichtangaben** für eure Nische.

Der schnellste Weg dorthin ist nicht, sie selbst zu tippen: `@Strategie` kann
dich interviewen und die Datei schreiben. Zum Beispiel:

```
@Strategie interviewe mich zur Stil-DNA unseres Copywritings und
schreib das Ergebnis in .claude/agents/copywriter.md an die Stelle
des Platzhalters. Frag einzeln, nicht alles auf einmal.
```

## Erst testen, dann füllen

Vor dem Ausfüllen einmal prüfen, dass die Ketten überhaupt greifen:

```
@Copywriting schreib 3 Hooks für einen PKV-Vergleich
```

Erwartet: Abbruch mit Hinweis auf das fehlende Master-Briefing. **Das ist der
Erfolgsfall** — Kette A und die Briefing-Voraussetzung funktionieren. Kommen
stattdessen einfach drei Hooks, ist `CLAUDE.md` nicht in der Wurzel gelandet.
