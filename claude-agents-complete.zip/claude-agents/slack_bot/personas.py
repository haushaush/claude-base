"""Several Slack identities, one bot process, one workspace.

A Slack app owns exactly one bot user, so `@grafik` and `@website` have to be
separate apps. That does NOT mean separate agent sets: every app here opens its
own Socket Mode connection into the *same* process, which serves them from the
same `/workspace`, the same `CLAUDE.md` and the same `SessionManager`.

What that buys, compared to one container per area:
  * one `claude` login and one MCP authorisation instead of N — the OAuth
    dance for remote connectors is the expensive part, and it happens once
  * one copy of the skills folder, so nothing drifts apart
  * chains stay intact: `copywriter -> qa-review` runs inside one Claude
    session, and sessions are keyed by thread, not by persona. Mention
    `@website` and then `@copywriter` in the same thread and both talk to the
    same running session

Which app a payload came from is in `api_app_id`, present on every Socket Mode
envelope. That is how a handler knows which persona was addressed without
needing a separate copy of itself per app.

Config lives next to credentials.json as personas.json:

    {
      "allowed_user_ids": "U01ABCDEF,U02GHIJKL",
      "allowed_channel_ids": "",
      "personas": [
        {"key": "website", "name": "Website", "subagent": "lp-builder",
         "command_prefix": "web",
         "bot_token": "xoxb-…", "app_token": "xapp-…"}
      ]
    }
"""

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

MODULE_DIR = Path(__file__).resolve().parent
PERSONAS_FILE = Path(os.getenv("PERSONAS_FILE", MODULE_DIR / ".personas.json"))


@dataclass(frozen=True)
class Persona:
    key: str
    name: str
    bot_token: str
    app_token: str
    # Which subagent this door leads to. A hint for the orchestrator, not a
    # hard route — the chains in CLAUDE.md still decide what actually runs.
    subagent: str | None = None
    # Slash commands must be unique per workspace, so each persona owns its own
    # namespace: /web-reset, /gfx-reset, …
    command_prefix: str = ""
    # Optional per-persona channel restriction, on top of the global allowlist.
    channel_ids: tuple[str, ...] = ()
    # Skill folder names this door should reach for, e.g.
    # ("copywriter-agent", "qa-review-agent"). Steering, not a permission:
    # every skill stays technically visible because they all live in one
    # workspace. Naming them shifts the model's default without cutting off a
    # skill that turns out to be needed — which matters for the chains, where
    # qa-review has to run no matter which door the request came through.
    skills: tuple[str, ...] = ()
    # Where this door's own knowledge lives, relative to the workspace.
    # Defaults to .hermes/bereiche/<key>. Global knowledge stays in .hermes/ —
    # see prompt_prefix for the split that is communicated to the model.
    context_dir: str = ""

    @property
    def prefix(self) -> str:
        return self.command_prefix or self.key

    @property
    def context(self) -> str:
        return self.context_dir or f".hermes/bereiche/{self.key}"

    def prompt_prefix(self) -> str:
        """Prepended to the user's message so the orchestrator knows the door."""
        parts = [f"Diese Anfrage kam über @{self.name}."]
        if self.subagent:
            parts.append(
                f"Zuständig ist primär der Subagent `{self.subagent}` — nutze ihn, "
                f"sofern die Aufgabe dazu passt."
            )
        if self.skills:
            named = ", ".join(f"`{s}`" for s in self.skills)
            parts.append(
                f"Einschlägig sind hier die Skills {named}. Andere Skills nur "
                f"laden, wenn die Aufgabe sie wirklich verlangt."
            )
        # The knowledge split. Global = what every door needs (who the client
        # is, what the domain requires). Local = the craft of this one area.
        # Stated as a read rule AND a write rule, because the write side is
        # where a shared store quietly turns into a private one.
        parts.append(
            f"Wissen: global gilt `.hermes/` (Kunden, Fachdomäne, alles was jeder "
            f"Bereich braucht), bereichslokal gilt `{self.context}/`. Lies zuerst "
            f"`.hermes/MEMORY.md`, dann `{self.context}/MEMORY.md`. Neue Notizen: "
            f"kundenbezogen oder fachlich → `.hermes/memories/`, handwerklich und "
            f"nur für diesen Bereich → `{self.context}/memories/`. Index jeweils "
            f"mitpflegen. Fremde Bereichsordner unter `.hermes/bereiche/` nicht "
            f"lesen, ausser eine Kette verlangt es ausdrücklich."
        )
        parts.append(
            "Die verbindlichen Ketten aus CLAUDE.md gelten unverändert; wenn eine "
            "Kette einen anderen Agenten oder Skill vorschreibt, hat sie Vorrang."
        )
        return "[" + " ".join(parts) + "]\n\n"


def _parse_ids(raw) -> tuple[str, ...]:
    if not raw:
        return ()
    if isinstance(raw, list):
        return tuple(str(x).strip() for x in raw if str(x).strip())
    raw = str(raw).strip()
    if raw.startswith("["):
        try:
            return tuple(str(x).strip() for x in json.loads(raw) if str(x).strip())
        except json.JSONDecodeError:
            logger.error("could not parse id list: %r", raw)
            return ()
    return tuple(x.strip() for x in raw.split(",") if x.strip())


def _read() -> dict:
    try:
        with open(PERSONAS_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
            return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return {}
    except (OSError, json.JSONDecodeError):
        logger.error("could not read %s", PERSONAS_FILE, exc_info=True)
        return {}


def load_personas() -> list[Persona]:
    """Read and validate the persona list. Bad entries are dropped, not fatal.

    One broken persona should not take the other four offline — but it is
    logged loudly, because a silently missing @name looks like a Slack problem
    and costs an hour to trace.
    """
    data = _read()
    raw = data.get("personas")
    if not isinstance(raw, list) or not raw:
        raise RuntimeError(
            f"No personas configured in {PERSONAS_FILE}. Expected a "
            '"personas" array with at least one {key, name, bot_token, app_token}.'
        )

    out: list[Persona] = []
    seen_prefix: set[str] = set()
    for i, p in enumerate(raw):
        if not isinstance(p, dict):
            logger.error("persona #%d is not an object — skipped", i)
            continue
        key = str(p.get("key", "")).strip()
        bot = str(p.get("bot_token", "")).strip()
        app = str(p.get("app_token", "")).strip()
        missing = [n for n, v in (("key", key), ("bot_token", bot), ("app_token", app)) if not v]
        if missing:
            logger.error("persona %r is missing %s — skipped", key or i, ", ".join(missing))
            continue

        persona = Persona(
            key=key,
            name=str(p.get("name") or key),
            bot_token=bot,
            app_token=app,
            subagent=(str(p["subagent"]).strip() or None) if p.get("subagent") else None,
            command_prefix=str(p.get("command_prefix", "")).strip().strip("/"),
            channel_ids=_parse_ids(p.get("channel_ids")),
            skills=_parse_ids(p.get("skills")),
            context_dir=str(p.get("context_dir", "")).strip().strip("/"),
        )
        if persona.prefix in seen_prefix:
            logger.error(
                "persona %r reuses the command prefix %r — Slack rejects "
                "duplicate slash commands in a workspace; skipped",
                key, persona.prefix,
            )
            continue
        seen_prefix.add(persona.prefix)
        out.append(persona)

    if not out:
        raise RuntimeError(f"No usable personas in {PERSONAS_FILE} — see errors above.")
    logger.info("personas: %s", ", ".join(f"@{p.name} (/{p.prefix}-*)" for p in out))
    return out


def session_scope() -> str:
    """"persona" (default) or "thread".

    persona — every door gets its own Claude session, even inside one thread.
              Contexts never mix; the price is that @copy knows nothing about
              what @website just did in the same thread.
    thread  — one session per thread, shared by whichever doors are used in it.
              Continuity across personas, at the cost of a mixed context.

    Persistent state (.hermes, kunden-briefings, the workspace itself) is shared
    either way — that is the point of one workspace. This only governs the live
    conversation context.
    """
    val = str(_read().get("session_scope", "") or os.getenv("SESSION_SCOPE", "")).strip().lower()
    if val in ("persona", "thread"):
        return val
    if val:
        logger.error("unknown session_scope %r — falling back to 'persona'", val)
    return "persona"


def global_allowed_user_ids() -> set[str]:
    return set(_parse_ids(_read().get("allowed_user_ids"))) or set(
        _parse_ids(os.getenv("SLACK_ALLOWED_USER_IDS", ""))
    )


def global_allowed_channel_ids() -> set[str]:
    return set(_parse_ids(_read().get("allowed_channel_ids"))) or set(
        _parse_ids(os.getenv("SLACK_ALLOWED_CHANNEL_IDS", ""))
    )
