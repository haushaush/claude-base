#!/usr/bin/env bash
# Wissensstruktur für einen Multi-Persona-Agenten anlegen.
#
#   cd /opt/claude-bot
#   bash scaffold-context.sh agents/fulfillment/workspace strategie copy website media grafik
#
# Idempotent: vorhandene Dateien werden nie überschrieben. Ein zweiter Lauf
# ergänzt nur, was fehlt — die Bereichsspeicher wachsen im Betrieb und dürfen
# nicht von einem Setup-Skript planiert werden.
set -euo pipefail

WS="${1:-}"
shift || true
BEREICHE=("$@")

[ -n "$WS" ] || { echo "Aufruf: bash scaffold-context.sh <workspace> <bereich> [<bereich> …]"; exit 1; }
[ -d "$WS" ] || { echo "FEHLER: $WS existiert nicht"; exit 1; }
[ ${#BEREICHE[@]} -gt 0 ] || { echo "FEHLER: mindestens ein Bereich"; exit 1; }

say(){ printf '\n\033[1m%s\033[0m\n' "$*"; }
ok(){ printf '  ✓ %s\n' "$*"; }
skip(){ printf '  · %s (existiert)\n' "$*"; }

write() {  # write <pfad> <<'EOF' … EOF
    local f="$1"
    if [ -e "$f" ]; then skip "$(basename "$(dirname "$f")")/$(basename "$f")"; cat > /dev/null; return; fi
    mkdir -p "$(dirname "$f")"
    cat > "$f"
    ok "$(basename "$(dirname "$f")")/$(basename "$f")"
}

say "Global"

mkdir -p "$WS/.hermes/memories"

write "$WS/.hermes/MEMORY.md" <<'EOF'
# MEMORY — global

Gilt für **alle** Bereiche. Hier steht, was jede Persona braucht: wer die
Kunden sind, was fachlich gilt, wie wir arbeiten.

Was hier NICHT hingehört: Handwerkswissen eines einzelnen Bereichs. Wie man
eine Meta-Kampagne diagnostiziert, gehört nach `bereiche/media/`, nicht hierher.

Faustregel: Würde eine andere Persona diese Notiz brauchen? Ja → hier. Nein →
in den Bereichsordner.

## Index

- [SOUL](SOUL.md) — wer ich bin, wie ich spreche, wie ich mich erinnere
- [USER](USER.md) — das Modell der Person, für die ich arbeite

### Notizen
_(eine Zeile je Datei in `memories/` — beim Anlegen einer Notiz mitpflegen)_

### Bereiche
_(je Bereich ein eigener Index unter `bereiche/<key>/MEMORY.md`)_
EOF

write "$WS/.hermes/memories/_konventionen.md" <<'EOF'
# Konventionen für den Wissensspeicher

## Zwei Ebenen

**Global — `.hermes/`**
Kunden (wer, was verkaufen sie, an wen), Fachdomäne (Versicherung, rechtliche
Rahmen, Zielgruppenlogik), Arbeitsweise, Entscheidungen mit Wirkung über
Bereichsgrenzen hinweg.

**Bereichslokal — `.hermes/bereiche/<key>/`**
Handwerk genau dieses Bereichs: Werkzeugeigenheiten, Formate, Kennzahlen,
Fehler, in die man dort zweimal getappt ist.

## Der Test beim Schreiben

Vor jeder Notiz eine Frage: *Würde eine andere Persona das brauchen?*
Ja → global. Nein → lokal. Im Zweifel lokal — eine Notiz hochzuziehen ist
leichter, als eine falsch verallgemeinerte wieder einzufangen.

## Regeln

- Eine Notiz, ein Thema. Dateiname sagt, worum es geht.
- Querverweise mit `[[slug]]`.
- Jede neue Notiz bekommt eine Zeile im zuständigen `MEMORY.md`. Ein Index,
  der nicht mitwächst, ist nach zwei Wochen wertlos.
- Keine Zugangsdaten. Nur Status: „Connector aktiviert", „Token liegt vor".
- Keine erfundenen Zahlen. Fehlt der Beleg, wird er als `[PROOF: …]` markiert.
EOF

for b in "${BEREICHE[@]}"; do
    say "Bereich: $b"
    mkdir -p "$WS/.hermes/bereiche/$b/memories"
    write "$WS/.hermes/bereiche/$b/MEMORY.md" <<EOF
# MEMORY — $b

Bereichslokal. Gilt nur für Anfragen, die über die \`$b\`-Tür kommen.

Global gültiges Wissen steht in [../../MEMORY.md](../../MEMORY.md) und wird
zuerst gelesen. Was hier steht, ergänzt es — es ersetzt es nicht und
widerspricht ihm nicht. Bei Widersprüchen gewinnt das Master-Briefing des
Kunden.

## Index
_(eine Zeile je Datei in \`memories/\` — beim Anlegen mitpflegen)_
EOF
done

say "Regelblock für CLAUDE.md"
cat <<'EOF'

  Diesen Abschnitt in workspace/CLAUDE.md aufnehmen, falls noch nicht drin:

  ## Wissensebenen

  - `.hermes/` ist global: Kunden, Fachdomäne, Arbeitsweise. Jede Persona liest
    es zu Sessionbeginn.
  - `.hermes/bereiche/<key>/` ist bereichslokal. Es wird zusätzlich gelesen,
    wenn die Anfrage über die entsprechende Tür kam.
  - Fremde Bereichsordner werden nicht gelesen, ausser eine Kette verlangt es.
  - Schreibregel: Würde eine andere Persona die Notiz brauchen? Ja → global,
    nein → lokal. Im Zweifel lokal.
  - Jede neue Notiz bekommt eine Zeile im zuständigen MEMORY.md.

EOF

chown -R 1000:1000 "$WS/.hermes" 2>/dev/null || true
ok "Rechte auf uid 1000"
