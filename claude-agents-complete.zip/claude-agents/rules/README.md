# Regel- und Wissensebenen

Drei Ebenen, jede Regel an genau einer Stelle.

| Ebene | Datei | Gilt für | Geladen |
|---|---|---|---|
| Global — Regeln | `CLAUDE.md` | alle Türen | jede Nachricht |
| Global — Wissen | `.hermes/` | alle Türen | Sessionbeginn |
| Tür | `personas.json` | eine Tür | pro Anfrage |
| Bereich — Wissen | `.hermes/bereiche/<tür>/` | eine Tür | Sessionbeginn |
| Prozedur | `.claude/skills/<name>/` | wer sie braucht | bei Bedarf |
| Kunde | `kunden-briefings/<slug>/` | wer daran arbeitet | bei Bedarf |

## Der Grundsatz

Eine Regel steht **einmal**. Personas wiederholen keine globalen Regeln — ihr
Prompt verweist nur darauf und stellt klar, dass sie Vorrang haben. Ein neuer
Bereich erbt damit alles: Gates, Ketten, Leitplanken, Kundenwissen. Einzurichten
ist nur, was ihn von den anderen unterscheidet.

## Einen Bereich hinzufügen

1. Slack-App anlegen, Tokens holen
2. Eintrag in `personas.json`: `key`, `name`, `subagent`, `skills`,
   `command_prefix`, `channel_ids`
3. `bash scaffold-context.sh <workspace> <key>` — legt den Bereichsordner an
4. `docker compose up -d --force-recreate`

Nichts davon fasst `CLAUDE.md` an. Wenn du beim Hinzufügen einer Tür eine
globale Regel ändern musst, war sie nicht global genug.

## Wenn eine Regel wandert

Symptom: dieselbe Anweisung steht in `CLAUDE.md` **und** in einem
Bereichsordner. Dann ist sie entweder global (raus aus dem Bereich) oder
bereichslokal (raus aus CLAUDE.md). Beides gleichzeitig ist der Zustand, in
dem später niemand mehr weiß, welche Fassung gilt.
