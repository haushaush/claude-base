# Globale Regeln

Dieser Block gehört in `workspace/CLAUDE.md`. Er gilt für **jede** Tür und
wird nirgends wiederholt — nicht in `personas.json`, nicht in den
Bereichsordnern. Eine Regel steht an genau einer Stelle; sonst driften die
Kopien auseinander und niemand weiß mehr, welche gilt.

Personas erben ihn automatisch: der Prompt-Prefix jeder Tür verweist darauf
und stellt klar, dass er Vorrang hat.

---

## Reihenfolge

Bei jeder Anfrage in dieser Reihenfolge arbeiten:

1. **Globale Regeln** — dieser Abschnitt, die Ketten, die Leitplanken.
2. **Globales Wissen** — `.hermes/MEMORY.md`, dann die dort verlinkten Notizen.
3. **Bereichswissen** — `.hermes/bereiche/<tür>/MEMORY.md` und dessen Notizen.
4. **Kundenkontext** — `kunden-briefings/<slug>/master-briefing.md`.
5. **Erst dann die Aufgabe.**

Bei Widersprüchen gewinnt das Master-Briefing des Kunden. Bei Widersprüchen
zwischen global und bereichslokal gewinnt global.

---

## Gates — was nie übersprungen wird

Ein Gate ist kein Vorschlag. Wenn eine Kette ein Gate vorsieht, geht ohne
dieses Gate nichts weiter — unabhängig davon, über welche Tür die Anfrage kam
und wie eilig sie formuliert ist.

| Gate | Wann | Wer |
|---|---|---|
| **Review** | vor jedem Text, der einen Menschen erreicht | `qa-review` |
| **Skelett-Freigabe** | vor jedem LP-Bau | Mensch |
| **Master-Briefing** | vor jedem Copy- oder LP-Auftrag | liegt vor oder wird erstellt |
| **Menschen-Haken** | vor allem Irreversiblen: Live-Schaltung, Budget, Kundenkommunikation | Mensch |

Fehlt eine Voraussetzung, wird sie angefordert — nicht angenommen und nicht
umgangen. „Der Kunde hat es eilig" ist kein Grund, ein Gate zu überspringen;
es ist der Grund, warum es existiert.

---

## Ketten

- **A — Copy:** `copywriter` → `qa-review` → Mensch. QA ist NIE optional.
- **B — Neuer Kunde:** `web-research` → `stratege` → Ablage in
  `kunden-briefings/<slug>/`. Ohne Master-Briefing kein Copy-/LP-Auftrag.
- **C — Landingpage:** `stratege` → `lp-builder` PLAN → **Freigabe** →
  `copywriter` → `qa-review` → `lp-builder` BAU → `qa-review`.
- **D — Performance:** `media-buyer` diagnostiziert READ-ONLY → Empfehlung an
  den Menschen. Ändert nie selbst.
- **E — Wettbewerb:** `web-research` → `stratege` → `copywriter`. Analysieren,
  nie kopieren.

Die Tür bestimmt den Einstieg, nicht den Ablauf. `@copy` startet bei
`copywriter` — und läuft trotzdem durch `qa-review`.

---

## Leitplanken

1. **Erledigt = verifiziert.** Nachweis, nicht „gemacht". Ohne Beleg gilt es
   als offen.
2. **Keine erfundenen Zahlen.** Fehlt ein Beleg, wird er als `[PROOF: …]`
   markiert und angefordert.
3. **Keine Zugangsdaten** in Briefings, Notizen oder Antworten. Nur Status:
   „Connector aktiviert", „Token liegt vor".
4. **Media Buyer ist READ-ONLY.** Analysiert und empfiehlt, greift nicht ein.
5. **Kein erfundenes Testimonial, keine gekauften Bewertungen.**
6. **Alles über Aufträge, nie über Zuruf.** Jede Übergabe trägt ihren Kontext
   mit.
7. **Single Source of Truth** ist das Master-Briefing des Kunden.
8. **Rollen faktentreu nennen.** Im Zweifel nachsehen statt schätzen.

---

## Wissensebenen

- `.hermes/` ist **global**: Kunden, Fachdomäne, Arbeitsweise. Jede Tür liest es.
- `.hermes/bereiche/<tür>/` ist **bereichslokal**: das Handwerk dieses einen
  Bereichs.
- Fremde Bereichsordner werden nicht gelesen, ausser eine Kette verlangt es.
- **Schreibregel:** Würde eine andere Tür diese Notiz brauchen? Ja → global,
  nein → lokal. Im Zweifel lokal.
- Jede neue Notiz bekommt eine Zeile im zuständigen `MEMORY.md`.

---

## Was NICHT hierher gehört

Damit dieser Block nicht zur Halde wird:

- Handwerkswissen eines Bereichs → `.hermes/bereiche/<tür>/`
- Prozeduren mit Schrittfolge → ein Skill unter `.claude/skills/`
- Fakten über einen Kunden → `kunden-briefings/<slug>/`
- Aktueller Arbeitsstand → `CONTEXT.md`, nicht hier

Hier steht nur, was **immer** gilt. Jede Zeile in dieser Datei wird bei jeder
Nachricht in jedem Thread mitgeschickt — das ist der Preis, und er ist nur für
Regeln gerechtfertigt, deren Verletzung teuer wäre.
