# MEMORY — <bereich>

Bereichslokal. Gilt nur für Anfragen über die `<bereich>`-Tür.

Global steht in [../../MEMORY.md](../../MEMORY.md) und wird zuerst gelesen.
Die Regeln und Gates aus `CLAUDE.md` gelten unverändert — hier werden sie
**nicht** wiederholt. Was hier steht, ergänzt; es widerspricht nie.

## Was hier hingehört

- Werkzeugeigenheiten dieses Bereichs
- Formate, Kennzahlen, Grenzwerte, mit denen hier gearbeitet wird
- Fehler, in die man hier zweimal getappt ist
- Absprachen, die nur diesen Bereich betreffen

## Was NICHT hier hingehört

- Kundenwissen → global
- Fachdomäne (z. B. rechtliche Rahmen) → global
- Regeln und Gates → CLAUDE.md
- Prozeduren mit Schrittfolge → ein Skill

## Index
_(eine Zeile je Datei in `memories/` — beim Anlegen mitpflegen)_
