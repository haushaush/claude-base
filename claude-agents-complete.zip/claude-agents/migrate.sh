#!/usr/bin/env bash
# Migration: ein Einzel-Bot -> Multi-Agent mit Personas.
#
#   cd /opt/claude-bot
#   bash migrate.sh --dry-run     # zeigt nur, was passieren würde
#   bash migrate.sh
#
# Idempotent. Bricht ab, wenn etwas nicht so aussieht wie erwartet, statt zu
# raten.
#
# WAS ERHALTEN BLEIBT (und warum das nicht selbstverständlich ist):
#
#   Das Named Volume behält den Namen `claude_home`. Darin stecken dein
#   Claude-Login UND die Onepage-OAuth-Autorisierung. Hätte der neue
#   Compose-Stand es `home_lp` genannt, würde Docker ein leeres Volume anlegen
#   und du müsstest beides neu machen — inklusive der localhost-Prozedur.
#
#   `credentials.json` wird nicht gelöscht, sondern nach personas.json
#   übersetzt. Das Original bleibt als .bak liegen.
set -euo pipefail

DRY=0
[ "${1:-}" = "--dry-run" ] && DRY=1

say(){ printf '\n\033[1m%s\033[0m\n' "$*"; }
ok(){ printf '  ✓ %s\n' "$*"; }
warn(){ printf '  ! %s\n' "$*"; }
die(){ printf '\n  ABBRUCH: %s\n\n' "$*"; exit 1; }
run(){ if [ $DRY -eq 1 ]; then printf '  … %s\n' "$*"; else eval "$@"; fi; }

[ -f docker-compose.yml ] || die "keine docker-compose.yml — im Verzeichnis /opt/claude-bot ausführen"
[ -d slack_bot ] || die "kein slack_bot/ — falsches Verzeichnis?"

say "0  Bestandsaufnahme"
[ -f credentials.json ] && ok "credentials.json gefunden" || warn "keine credentials.json"
[ -d workspace ] && ok "workspace/ gefunden ($(find workspace -type f 2>/dev/null | wc -l) Dateien)" || warn "kein workspace/"
docker volume ls --format '{{.Name}}' | grep -q '^claude-bot_claude_home$' \
    && ok "Volume claude-bot_claude_home existiert — Login bleibt erhalten" \
    || warn "Volume claude-bot_claude_home nicht gefunden — Login ggf. neu nötig"

say "1  Sicherung"
STAMP=$(date +%Y%m%d-%H%M%S)
run "mkdir -p /root/claude-bot-backup-$STAMP"
run "cp -a docker-compose.yml Dockerfile slack_bot /root/claude-bot-backup-$STAMP/ 2>/dev/null || true"
[ -f credentials.json ] && run "cp -a credentials.json /root/claude-bot-backup-$STAMP/"
ok "nach /root/claude-bot-backup-$STAMP"

say "2  Container stoppen"
run "docker compose down"

say "3  Verzeichnisse umbauen"
run "mkdir -p agents/lp agents/fulfillment/workspace"
if [ -d workspace ] && [ ! -d agents/lp/workspace ]; then
    run "mv workspace agents/lp/workspace"
    ok "workspace/ -> agents/lp/workspace/"
else
    ok "agents/lp/workspace existiert bereits"
fi
[ -f credentials.json ] && [ ! -f agents/lp/credentials.json ] \
    && run "mv credentials.json agents/lp/credentials.json" \
    && ok "credentials.json -> agents/lp/"

say "4  credentials.json -> personas.json"
if [ -f agents/lp/personas.json ]; then
    ok "personas.json existiert bereits — unverändert"
elif [ -f agents/lp/credentials.json ]; then
    if [ $DRY -eq 1 ]; then
        printf '  … agents/lp/personas.json aus credentials.json erzeugen\n'
    else
        python3 - <<'PYEOF'
import json, pathlib
src = json.load(open("agents/lp/credentials.json"))
out = {
    "session_scope": "persona",
    "allowed_user_ids": src.get("slack_allowed_user_ids", ""),
    "allowed_channel_ids": src.get("slack_allowed_channel_ids", ""),
    "personas": [{
        "key": "lp",
        "name": "Website",
        "subagent": "",
        "skills": "",
        "command_prefix": "lp",
        "bot_token": src.get("slack_bot_token", ""),
        "app_token": src.get("slack_app_token", ""),
    }],
}
p = pathlib.Path("agents/lp/personas.json")
p.write_text(json.dumps(out, indent=2, ensure_ascii=False))
p.chmod(0o600)
print("  ✓ agents/lp/personas.json erzeugt (eine Persona: @Website, /lp-*)")
PYEOF
        chown 1000:1000 agents/lp/personas.json 2>/dev/null || true
    fi
    warn "ACHTUNG: die Slash-Commands heissen jetzt /lp-* statt /claude-*."
    warn "  Im Slack-App-Manifest anpassen, sonst laufen sie ins Leere."
else
    warn "keine credentials.json — personas.json von Hand aus personas.example.json anlegen"
fi

say "5  Code und Compose einspielen"
run "cp -a NEU/slack_bot/. slack_bot/"
run "cp -a NEU/Dockerfile Dockerfile"
run "cp -a NEU/docker-compose.yml docker-compose.yml"
run "cp -a NEU/claude-agents ." 
for f in scaffold-context.sh install-fulfillment.sh verify-fulfillment.sh new-agent.sh \
         slack-app-manifest.template.yml personas.example.json connectors.env.example; do
    [ -f "NEU/$f" ] && run "cp -a NEU/$f ."
done
run "chmod +x *.sh"
ok "Dateien eingespielt"

say "6  Rechte und .gitignore"
run "chown -R 1000:1000 agents/ 2>/dev/null || true"
if ! grep -q 'agents/\*/personas.json' .gitignore 2>/dev/null; then
    run "printf 'agents/*/personas.json\nagents/*/credentials.json\nagents/*/connectors.env\nagents/*/workspace/\n' >> .gitignore"
    ok ".gitignore ergänzt"
else
    ok ".gitignore war schon vollständig"
fi

say "7  Prüfen"
if [ $DRY -eq 0 ]; then
    python3 -m py_compile slack_bot/*.py && ok "Python-Syntax"
    python3 -c "import json;json.load(open('agents/lp/personas.json'))" 2>/dev/null && ok "personas.json ist gültiges JSON"
    grep -q 'claude_home' docker-compose.yml && ok "Volume claude_home beibehalten — Login bleibt" \
        || die "docker-compose.yml nennt claude_home nicht — Login würde verloren gehen"
fi

cat <<'EOF'

Weiter:

  docker compose up -d --build agent-lp
  docker compose logs -f agent-lp

  Im Log erwarten:
    personas: @Website (/lp-*)
    ⚡Bolt app is running!

  Erst wenn der LP-Bot wieder antwortet, den fulfillment-Bot dazunehmen:
    bash install-fulfillment.sh /pfad/zum/entpackten/agentur
    bash scaffold-context.sh agents/fulfillment/workspace strategie copy website media grafik
    nano agents/fulfillment/personas.json
    docker compose up -d --build agent-fulfillment

EOF
