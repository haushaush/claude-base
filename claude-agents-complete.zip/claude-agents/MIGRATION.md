# Umstellung des bestehenden Containers

Ein Paket auf Endstand. Ersetzt alles, was in den letzten Runden einzeln kam —
mehrere dieser Pakete überschrieben einander, hier ist nur die jeweils neueste
Fassung drin.

## Was sich ändert

| Vorher | Nachher |
|---|---|
| ein Service `claude-slack-bot` | `agent-lp` + `agent-fulfillment` |
| `credentials.json` | `personas.json` |
| `./workspace` | `./agents/lp/workspace` |
| `/claude-*` Slash-Commands | `/lp-*` (bzw. pro Persona) |
| ein @Name | ein @Name je Bereich |

## Ablauf

```bash
cd /opt/claude-bot

# 1. Paket entpacken — NEBEN das bestehende Verzeichnis, nicht hinein
mkdir -p NEU && cd NEU
# ZIP hierher, entpacken, sodass NEU/slack_bot, NEU/docker-compose.yml … liegen
cd ..

# 2. Erst ansehen, was passieren würde
cp NEU/migrate.sh . && chmod +x migrate.sh
bash migrate.sh --dry-run

# 3. Wenn das plausibel aussieht
bash migrate.sh
```

Das Skript stoppt die Container, sichert nach `/root/claude-bot-backup-<datum>`,
baut die Verzeichnisse um, übersetzt `credentials.json` nach `personas.json`,
spielt Code und Compose ein und prüft die Syntax. Es überschreibt keine
vorhandene `personas.json` und löscht nichts.

## Der Punkt, an dem es schiefgehen kann

Das Named Volume heißt weiterhin `claude_home`. Darin stecken dein
**Claude-Login und die Onepage-Autorisierung**. Hätte die neue Compose-Datei es
`home_lp` genannt, würde Docker ein leeres Volume anlegen — und du dürftest
beides neu machen, inklusive der localhost-Prozedur.

Das Skript prüft das und bricht ab, wenn der Name fehlt. Nach der Migration
gegenprüfen:

```bash
docker volume ls | grep claude_home
docker compose run --rm --entrypoint claude agent-lp -p "sag hallo"
```

Kommt eine Antwort, ist der Login intakt.

## Nach der Migration

```bash
docker compose up -d --build agent-lp
docker compose logs -f agent-lp
```

Im Log:

```
personas: @Website (/lp-*)
onepage MCP enabled (https://mcp.onepage.io/)
⚡Bolt app is running!
```

**Ein Schritt in Slack ist nötig:** die Slash-Commands heißen jetzt `/lp-*`
statt `/claude-*`. Im App-Manifest anpassen (api.slack.com → deine App → App
Manifest) und die App neu installieren. Erwähnungen funktionieren sofort, nur
die Commands nicht.

## Erst danach der zweite Bot

`agent-fulfillment` liegt hinter einem Compose-Profil und startet nicht
versehentlich mit. Das ist Absicht: ein halb eingerichteter zweiter Bot macht
die Fehlersuche am ersten unnötig schwer.

```bash
# 1. Agent-Set einpassen
bash install-fulfillment.sh /pfad/zum/entpackten/agentur

# 2. Wissensstruktur anlegen
bash scaffold-context.sh agents/fulfillment/workspace \
     strategie copy website media grafik

# 3. Globalen Regelblock in CLAUDE.md aufnehmen
cat rules/CLAUDE-global-block.md   # Inhalt nach agents/fulfillment/workspace/CLAUDE.md

# 4. Slack-Apps: eine je Bereich, Tokens sammeln
cp personas.example.json agents/fulfillment/personas.json
nano agents/fulfillment/personas.json
chmod 600 agents/fulfillment/personas.json
chown 1000:1000 agents/fulfillment/personas.json

# 5. Meta-Connector
cp connectors.env.example agents/fulfillment/connectors.env
nano agents/fulfillment/connectors.env
chmod 600 agents/fulfillment/connectors.env

# 6. Starten
docker compose --profile fulfillment up -d --build agent-fulfillment
docker compose logs -f agent-fulfillment

# 7. Einmalig Claude-Login + Onepage in DIESEM Container
docker compose run --rm -it --entrypoint claude agent-fulfillment
```

Schritt 7 ist nötig, weil `agent-fulfillment` ein eigenes Home-Volume hat. Der
Login von `agent-lp` gilt dort nicht — getrennte Volumes waren die Entscheidung
gegen gleichzeitige Schreibzugriffe auf `~/.claude.json`.

## Ressourcen

`agent-lp` auf 3 GB, `agent-fulfillment` auf 4 GB. Bei 7,8 GB gesamt und n8n mit
rund 600 MB ist das knapp kalkuliert, wenn beide gleichzeitig arbeiten.

**Swap anlegen**, falls immer noch nicht geschehen — das steht seit dem ersten
Tag aus und ist hier der Unterschied zwischen „wird langsam" und „Prozess tot":

```bash
fallocate -l 4G /swapfile && chmod 600 /swapfile
mkswap /swapfile && swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
```

## Wenn etwas klemmt

| Symptom | Ursache |
|---|---|
| `No personas configured` | `personas.json` nicht gemountet oder leer |
| Persona fehlt im Log | doppelter `command_prefix` oder fehlender Token — Fehlerzeile darüber lesen |
| Login weg | Volume-Name geändert; `docker volume ls` prüfen |
| Slash-Commands tot | Manifest nicht angepasst oder App nicht neu installiert |
| Änderung wirkt nicht | `Built`, aber Container nicht ersetzt — `--force-recreate` |
| Connector fehlt in Session | MCP wird beim Session-Start registriert — neuer Thread |
