# Report-Format einbauen

```bash
cd /opt/claude-bot/agents/fulfillment/workspace
mkdir -p .claude/skills/report-format
# SKILL.md dorthin
chown -R 1000:1000 .claude
```

Kein Rebuild, kein Neustart — Skills liegen im Workspace. Aber **neuer Thread**.

Für den LP-Bot dasselbe, falls er auch Reports schreiben soll:

```bash
cp -a .claude/skills/report-format \
  /opt/claude-bot/agents/lp/workspace/.claude/skills/
chown -R 1000:1000 /opt/claude-bot/agents/lp/workspace/.claude
```

## Testen

```
@Mediabuying gib mir die 7-Tage-Auswertung für <Kunde>
```

Der Skill muss im Trace als geladen auftauchen. Wenn nicht, greift die
`description` nicht — dann die Wörter ergänzen, mit denen du tatsächlich
fragst.

## Nachschärfen

Das Format ist eine Datei. Was nicht passt, direkt ändern lassen:

```
@Mediabuying in .claude/skills/report-format/SKILL.md die Vorlage
für Mediabuying anpassen: <was anders soll>
```

Zwei Stellen würde ich mit der Zeit füllen, weil ich sie nicht kenne:

**Die Kohorten-Position.** Deine n8n-Regel sagt „Position 1/51 pro Account".
Woher die Vergleichsgruppe kommt und wie sie gebildet wird, steht nicht drin —
das gehört in die Mediabuying-Vorlage, sobald der Agent an die Daten kommt.

**Die Schwellen.** Ab welchem CPL ein ⚠️ gesetzt wird, weiß nur du. Solange das
fehlt, setzt der Agent es nach Gefühl, und das ist über Wochen nicht
vergleichbar.

## Warum ein Skill und nicht CLAUDE.md

`CLAUDE.md` wird bei jeder Nachricht in jedem Thread mitgeschickt. Diese 158
Zeilen würdest du also auch bei „was macht diese Funktion" bezahlen.

Als Skill liegt dauerhaft nur die `description` im Kontext — zwei Zeilen. Der
Rumpf kommt, wenn ein Report entsteht. Bei einem Setup, dessen Zweck das
Schonen des Kontingents ist, ist das der Unterschied zwischen tragbar und
teuer.
