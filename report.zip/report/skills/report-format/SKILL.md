---
name: report-format
description: Auswertungen und Berichte im Haush-Haush-Hausformat schreiben —
  KPI-Reports, Copy-Lieferungen, Briefing-Zusammenfassungen, LP-Status. Nutze
  das immer, wenn eine Auswertung, ein Wochenreport, eine Lieferung oder ein
  Status an einen Menschen oder Kunden geht. Auch bei "Report", "Auswertung",
  "Update", "wie läuft", "Zahlen zu".
---

# Report-Hausformat

Gilt für alle Bereiche. Ein Report ist kein Gesprächsbeitrag: er hat einen
festen Aufbau, damit man ihn über Wochen vergleichen kann.

## Aufbau

```
*<Kunde> – <Thema>*

<Ein Satz Kontext mit Zeitraum.>

<emoji> <Fakt in einer Zeile.>
<emoji> <Fakt in einer Zeile.>
<emoji> <Fakt in einer Zeile.>

<Kurzer Satz, der den nächsten Block einleitet:>

<emoji> <Detail in einer Zeile.>

---
```

## Harte Regeln

**Kein Summary-Block vorweg.** Keine Zusammenfassung dessen, was gleich kommt.
Der erste Fakt ist die Aussage.

**Eine Zeile, ein Fakt.** Kein Fließtext hinter dem Emoji. Passt ein Fakt nicht
in eine Zeile, sind es zwei Fakten.

**Zahlen immer mit Einheit und Bezug.** „CPL 60,27 €" statt „CPL 60,27". Beim
Zeitraum genügt die Angabe im Kontextsatz, sie muss nicht in jeder Zeile stehen.

**Keine Prozentvergleiche zur Vorwoche.** Bei den üblichen Fallzahlen ist das
Rauschen, nicht Entwicklung.

**Kein Beleg, kein Fakt.** Was der Connector nicht hergibt, kommt nicht in den
Report — es kommt als `[PROOF: …]` in einen eigenen Abschnitt am Ende.

**Bei kleinen Fallzahlen dazusagen.** Vier Leads sind kein Trend, und der Satz
dazu gehört in dieselbe Zeile, nicht in eine Fußnote.

**`---` am Ende**, nicht eine Reihe getippter Bindestriche. Die Bridge macht
daraus eine echte Trennlinie.

## Emoji-Vokabular

Feststehend, damit über Wochen dasselbe Symbol dasselbe bedeutet.

| Emoji | Bedeutung |
|---|---|
| ⭐ | Ergebnis — Leads, Abschlüsse, das Ziel |
| 🛠 | Effizienz — CPL, CPA, Kosten je Ergebnis |
| 🚀 | Reichweite — Impressionen, Klicks, CTR, CPC, CPM |
| 🥇 | Bester Performer im Zeitraum |
| ⚠️ | Auffälligkeit, die Aufmerksamkeit braucht |
| 🔴 | Blockierend, jemand muss handeln |
| 📄 | Lieferung — Text, Dokument, Seite |
| ✅ | Geprüft und bestanden |

Kein anderes Emoji. Kein Emoji als Dekoration.

## Vorlagen je Bereich

### Mediabuying

```
*<Kunde> – PKV*

Kurzes Update zu der Performance Deiner Meta Ads in den letzten 7 Tagen
(<von> – <bis>):

⭐ Es wurden <n> Leads bei <spend> € Werbebudget erzielt.
🛠 Der CPL lag bei <cpl> €.
🚀 Die Kampagnen erreichten <reach> Reichweite, <impr> Impressionen,
   <klicks> Klicks, <ctr> % CTR, <cpc> € CPC, <cpm> € CPM.

Am besten abgeliefert haben die Creatives:

🥇 „<Creative>" mit <n> Leads, <spend> € Spend, CPL <cpl> €.

---
```

Top **Creatives**, nicht Top Kampagnen. Konto-Position als „<n>/<gesamt>",
wenn ein Kohortenvergleich vorliegt.

### Copywriting

```
*<Kunde> – <Kanal>*

<n> Varianten, ausgerichtet auf <Zielgruppe> aus dem Master-Briefing.

📄 Variante 1 — <Ansatz in drei Worten>
📄 Variante 2 — <Ansatz in drei Worten>

<Die Varianten selbst darunter, je in einem eigenen Block.>

✅ Geprüft gegen Briefing, Stil und Compliance.

---
```

Der ✅-Eintrag steht nur da, wenn `qa-review` tatsächlich gelaufen ist. Ohne
QA-Durchgang bleibt die Zeile weg — nicht „wird noch geprüft" hinschreiben.

### Strategie

```
*<Kunde> – Briefing*

<Ein Satz: was ist neu oder entschieden.>

⭐ Angebot: <in einer Zeile>
⭐ Zielgruppe: <in einer Zeile>
⭐ Kernbotschaft: <in einer Zeile>

Offen:

[PROOF: <was fehlt und wer es liefert>]

---
```

### Website

```
*<Kunde> – Landingpage*

<Stand in einem Satz.>

📄 <n> Blöcke, davon <m> befüllt.
✅ Skelett freigegeben am <Datum>.
⚠️ <Auffälligkeit, falls vorhanden.>

---
```

## Wann kein Report

Auf eine Frage im Thread antworte ich normal, nicht im Reportformat. Der
Aufbau gilt für Auswertungen und Lieferungen — nicht für „warum ist der CPL
gestiegen".

Empfehlungen und Diagnosen sind ebenfalls kein Report: dort gilt die Stilnotiz
[[../../.hermes/memories/slack-style.md]] — Kernaussage in einer Zeile,
höchstens zwei Zeilen Begründung, `---` zwischen den Prioritätsstufen.
